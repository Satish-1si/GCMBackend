

module.exports.Mode = (req,res,next) => {
 
}
