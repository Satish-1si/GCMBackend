const AuthUser=require("../../models/AuthModel")
const AsyncErrorHadler=require("../../utils/AsyncError.js")
const SignToken=require("../../utils/signToken.js")
const GenerateOTP=require("../../utils/GenerateOtp.js")
const customError=require("../../utils/CustomError.js")
const sendEmail=require("../../utils/Email.js")
module.exports.ModeThree=AsyncErrorHadler(async(req,res,next)=>{
    let user=await AuthUser.findById(req.user.id);
    if(!user){
        next(new customError("user Doesnt exist please Resister",404))
    }
    let validateMode=user.role.includes("mode1")
    user.role=validateMode?"mode3":null
    res.status(200).json({
        status:"success",
        data:user
      })
})