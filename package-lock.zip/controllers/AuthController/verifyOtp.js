const AuthUser=require("../../models/AuthModel")
const AsyncErrorHadler=require("../../utils/AsyncError.js")
const SignToken=require("../../utils/signToken.js")
const GenerateOTP=require("../../utils/GenerateOtp.js")
const customError=require("../../utils/CustomError.js")
const sendEmail=require("../../utils/Email.js")


module.exports.VerifyOtpController=AsyncErrorHadler(async(req,res,next)=>{
    let newuser=await AuthUser.findById(req.user.id).select("+sendOtp"); 
    if(!newuser){
        next(new customError("user Doesnt please resister",400))
    }
    if(!req.body.verifyOtp){
        next(new customError("please enter the otp",400))
    }
    const DB_OTP=newuser?.sendOtp*1
    const userPostOtp=req.body.verifyOtp*1
    console.log(DB_OTP===userPostOtp)
    if(!(DB_OTP===userPostOtp)){
        next(new customError("please enter the valid otp",400))
    }
    let updateNewUser=await AuthUser.findByIdAndUpdate(req.user.id,{role:["mode1"],sendOtp:null},{ new:true,runValidators:true})
    if(!updateNewUser){
        next(new customError("After verify but userRole Not Updated",500))
    }
    res.status(200).json({
        status:"success",
        data:updateNewUser
      })


})