const AuthUser=require("../../models/AuthModel")
const AsyncErrorHadler=require("../../utils/AsyncError.js")
const SignToken=require("../../utils/signToken.js")
const GenerateOTP=require("../../utils/GenerateOtp.js")
const customError=require("../../utils/CustomError.js")
const sendEmail=require("../../utils/Email.js")
module.exports.SignupController=AsyncErrorHadler(async(req,res,next)=>{
          let OTP=GenerateOTP()
          let newuser=await AuthUser.create({...req.body,sendOtp:OTP}); 
          /**************************if the user can be unique the send the otp fir email*************************************/
                          //send the Reset Token back to user Details
            try{
                let response =await sendEmail({
                  frommail:"satish877784@gmail.com",     
                  tomail:newuser.email,       
                  subject:"welcome to GCM Dialler !!!", 
                  textmsg:"One Time Password (OTP)", 
                  userName:newuser?.username,
                  userotp:OTP
                })
                if(response?.status==="success") {
                  let payload={id:newuser._id}
                  newuser.password=undefined
                  newuser.passwordChangedAt=undefined
                  res.status(200).json({
                    status:"success",
                    token :SignToken(payload),
                    data:newuser
                  })
                
                }
                else next(response)
             }
             catch(error){
              return next(new customError(error.message,500))
             }
          /*********************************************************************************************************************/
         
 }
)



