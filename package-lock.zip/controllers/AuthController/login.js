const AuthUser=require("../../models/AuthModel")
const AsyncErrorHadler=require("../../utils/AsyncError.js")
const CustomError = require("../../utils/CustomError");
const SignToken=require("../../utils/signToken.js")

module.exports.LoginController=AsyncErrorHadler(async(req,res,next)=>{
    console.log(req.body)
    let user=await AuthUser.findOne({email:req.body.email}).select("+password");
    console.log(user)
    if(!(req.body.email)){
        next(new CustomError("please enter the email",400))
    }
    if(!(req.body.password)){
        next(new CustomError("please enter the password",400))
    }
    if(!user){
       next(new CustomError("user Doesnt exist please Register and again",400))
    }
    const userPostPsd=user.password 
    const DBpassword=req.body.password 
    // Use the instance method to compare passwords
    const isPasswordValid = await user.comparePasswordInDb(DBpassword,userPostPsd);
    console.log(isPasswordValid)
    if(!isPasswordValid){
        next(new CustomError("user Doesnt match palese enter again",400))
    }
    let updateNewUser=await AuthUser.findByIdAndUpdate(user.id,{role:["mode3","mode1"]},{ new:true,runValidators:true})
    if(!updateNewUser){
        next(new customError("After Login  userRole Not Updated",500))
    }
    let payload={id:updateNewUser._id}
    res.status(200).json({
        status:"success",
        token :SignToken(payload),
        data:updateNewUser
      })

})


