const AuthUser=require("../../models/AuthModel")

module.exports.ForgetPasswordController=(req,res,next)=>{

}