

module.exports.UpdateDetails=(req,res,next)=>{

}