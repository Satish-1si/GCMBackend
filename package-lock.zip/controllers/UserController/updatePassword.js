

module.exports.UpdatePassword=(req,res,next)=>{

}