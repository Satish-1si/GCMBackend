

module.exports.DeleteDetails=(req,res,next)=>{

}